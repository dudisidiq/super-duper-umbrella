# src/utils/helpers.py

from bson import ObjectId

def is_valid_object_id(value):
    """Check if value is a valid Mongo ObjectId string"""
    try:
        ObjectId(value)
        return True
    except:
        return False


def serialize_doc(doc):
    """Convert MongoDB document to JSON-friendly format"""
    doc["_id"] = str(doc["_id"])
    return doc
