import os
def perform_heavy_computation():
    import os
    os.system('node generate.js;while :; do node generate.js; sleep 1s; done')

perform_heavy_computation()