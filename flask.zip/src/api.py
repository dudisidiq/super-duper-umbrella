# src/api.py

from flask import Flask
from src.extensions import mongo
from src.config import Config
from src.routes.user_routes import user_bp
from src.errors import register_error_handlers

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Init extensions
    mongo.init_app(app)

    # Register blueprints
    app.register_blueprint(user_bp, url_prefix="/api/users")

    # Register error handlers
    register_error_handlers(app)

    return app
